package com.platform.ecommerce.pricing;

/**
 * Calculates promotional and tier-based discounts for customer orders.
 */
public class DiscountCalculator {

    /**
     * Computes total discount amount bounded between 0 and 40% of subtotal.
     */
    public double calculateDiscount(double subtotal, String loyaltyTier, String promoCode, int itemCount) {
        if (subtotal <= 0.0) {
            return 0.0;
        }

        double tierRate = 0.0;
        if ("GOLD".equals(loyaltyTier)) {
            tierRate = 0.08;
        } else if ("PLATINUM".equals(loyaltyTier)) {
            tierRate = 0.12;
        } else if ("SILVER".equals(loyaltyTier)) {
            tierRate = 0.04;
        }

        double promoRate = 0.0;
        if (promoCode != null && !promoCode.isEmpty()) {
            if ("WELCOME10".equals(promoCode)) {
                promoRate = 0.10;
            } else if ("BUNDLE15".equals(promoCode) && itemCount >= 3) {
                promoRate = 0.15;
            }
        }

        double combinedRate = tierRate + promoRate;
        if (combinedRate > 0.40) {
            combinedRate = 0.40;
        }
        return subtotal * combinedRate;
    }
}
