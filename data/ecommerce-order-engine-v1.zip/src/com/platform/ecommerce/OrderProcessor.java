package com.platform.ecommerce;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import com.platform.ecommerce.payment.PaymentGatewayService;
import com.platform.ecommerce.inventory.InventoryManager;
import com.platform.ecommerce.pricing.DiscountCalculator;
import com.platform.ecommerce.shipping.ShippingRateEstimator;
import com.platform.ecommerce.tax.TaxComplianceEngine;
import com.platform.ecommerce.validation.CustomerValidator;
import com.platform.ecommerce.audit.OrderAuditLogger;
import com.platform.ecommerce.notification.EmailDispatcher;
import com.platform.ecommerce.fraud.FraudRuleEngine;
import com.platform.ecommerce.loyalty.LoyaltyPointLedger;
import com.platform.ecommerce.warehouse.WarehouseRouter;
import com.platform.ecommerce.reporting.MetricsCollector;

public class OrderProcessor {
    private PaymentGatewayService paymentService;
    private InventoryManager inventoryManager;
    private DiscountCalculator discountCalculator;
    private ShippingRateEstimator shippingEstimator;
    private TaxComplianceEngine taxEngine;
    private CustomerValidator customerValidator;
    private OrderAuditLogger auditLogger;
    private EmailDispatcher emailDispatcher;
    private FraudRuleEngine fraudEngine;
    private LoyaltyPointLedger loyaltyLedger;
    private WarehouseRouter warehouseRouter;
    private MetricsCollector metricsCollector;
    private int maxRetryAttempts = 3;
    private double highValueThreshold = 5000.0;

    public String processCheckoutWorkflow(
        String orderId,
        String customerId,
        List<String> skuList,
        Map<String, Integer> quantities,
        Map<String, Double> unitPrices,
        String couponCode,
        String shippingRegion,
        String paymentMethod,
        boolean isExpressDelivery
    ) {
        if (orderId == null || orderId.isEmpty() || customerId == null || customerId.isEmpty()) {
            return "INVALID_ORDER_PARAMETERS";
        }
        if (skuList == null || skuList.isEmpty() || quantities == null || unitPrices == null) {
            return "EMPTY_CART_ITEMS";
        }

        double grossTotal = 0.0;
        int totalUnits = 0;

        for (int i = 0; i < skuList.size(); i++) {
            String sku = skuList.get(i);
            Integer qty = quantities.get(sku);
            Double price = unitPrices.get(sku);
            if (qty != null && qty > 0 && price != null && price >= 0.0) {
                if (qty > 100) {
                    if (shippingRegion.equals("INTL_RESTRICTED") || shippingRegion.equals("EMBARGO")) {
                        return "BULK_EXPORT_RESTRICTED";
                    } else {
                        if (price > 250.0 && !paymentMethod.equals("WIRE_TRANSFER")) {
                            return "HIGH_VOLUME_REQUIRES_WIRE";
                        } else {
                            grossTotal += (qty * price * 0.95);
                        }
                    }
                } else {
                    grossTotal += (qty * price);
                }
                totalUnits += qty;
            } else {
                return "INVALID_LINE_ITEM_" + sku;
            }
        }

        double discountAmount = 0.0;
        if (couponCode != null && !couponCode.isEmpty()) {
            if (couponCode.startsWith("VIP") && grossTotal >= 500.0) {
                discountAmount = grossTotal * 0.20;
            } else if (couponCode.startsWith("SEASONAL") && grossTotal >= 100.0) {
                discountAmount = grossTotal * 0.10;
            } else if (couponCode.equals("FLAT50") && grossTotal >= 200.0) {
                discountAmount = 50.0;
            } else if (couponCode.equals("STAFF_DISC")) {
                discountAmount = grossTotal * 0.25;
            }
        }

        double netTotal = grossTotal - discountAmount;
        if (netTotal < 0.0) {
            netTotal = 0.0;
        }

        double shippingFee = 15.0;
        if (isExpressDelivery) {
            if (shippingRegion.startsWith("INTL")) {
                shippingFee = 75.0 + (totalUnits * 3.5);
            } else {
                shippingFee = 30.0 + (totalUnits * 1.5);
            }
        } else {
            if (netTotal > 250.0 && !shippingRegion.startsWith("INTL")) {
                shippingFee = 0.0;
            } else {
                shippingFee = 12.0 + (totalUnits * 0.75);
            }
        }

        double finalPayable = netTotal + shippingFee;
        if (finalPayable >= highValueThreshold) {
            int attempt = 0;
            boolean verified = false;
            while (attempt < maxRetryAttempts && !verified) {
                attempt++;
                if (paymentMethod.equals("CREDIT_CARD") || paymentMethod.equals("WIRE_TRANSFER")) {
                    verified = true;
                }
            }
            if (!verified) {
                return "HIGH_VALUE_VERIFICATION_FAILED";
            }
        }

        return "ORDER_CONFIRMED:" + orderId + ":" + finalPayable;
    }

    public int evaluateOrderRiskScore(
        String customerTier,
        double orderAmount,
        int priorChargebacks,
        boolean billingMatchesShipping,
        String deviceFingerprint,
        int accountAgeDays
    ) {
        int score = 0;
        if (priorChargebacks > 0) {
            score += priorChargebacks * 35;
        }
        if (!billingMatchesShipping) {
            if (orderAmount > 1000.0) {
                score += 40;
            } else {
                score += 15;
            }
        }
        if (accountAgeDays < 7) {
            if (orderAmount > 500.0) {
                score += 30;
            } else {
                score += 10;
            }
        }
        if (deviceFingerprint == null || deviceFingerprint.length() < 8) {
            score += 25;
        }
        if ("PLATINUM".equals(customerTier) && priorChargebacks == 0) {
            score -= 20;
        }
        return score < 0 ? 0 : (score > 100 ? 100 : score);
    }

    public String reconcileStaleOrders(List<String> pendingIds, int timeoutMinutes, boolean forceCancel) {
        int cancelled = 0;
        int retained = 0;
        if (pendingIds != null) {
            for (String id : pendingIds) {
                if (id != null && !id.isEmpty()) {
                    if (timeoutMinutes > 120 || forceCancel) {
                        cancelled++;
                    } else {
                        retained++;
                    }
                }
            }
        }
        return "CANCELLED=" + cancelled + ",RETAINED=" + retained;
    }
}
