package com.platform.ecommerce.inventory;

import java.util.Map;
import java.util.HashMap;

/**
 * Manages warehouse stock levels, reservations, and reorder alerts.
 */
public class InventoryManager {
    private Map<String, Integer> stockBySku = new HashMap<>();
    private int safetyStockThreshold = 10;

    public InventoryManager() {
        stockBySku.put("SKU-1001", 120);
        stockBySku.put("SKU-1002", 45);
        stockBySku.put("SKU-1003", 8);
    }

    /**
     * Checks whether sufficient units are available for a requested SKU.
     */
    public boolean hasAvailableStock(String sku, int requestedUnits) {
        if (sku == null || requestedUnits <= 0) {
            return false;
        }
        Integer current = stockBySku.get(sku);
        return current != null && current >= requestedUnits;
    }

    /**
     * Reserves inventory units and returns reservation status code.
     */
    public String reserveStock(String sku, int requestedUnits, boolean allowBackorder) {
        if (sku == null || requestedUnits <= 0) {
            return "INVALID_REQUEST";
        }
        int available = stockBySku.getOrDefault(sku, 0);
        if (available >= requestedUnits) {
            stockBySku.put(sku, available - requestedUnits);
            return "RESERVED";
        } else if (allowBackorder && requestedUnits <= 25) {
            stockBySku.put(sku, available - requestedUnits);
            return "BACKORDERED";
        }
        return "INSUFFICIENT_STOCK";
    }

    public boolean needsReplenishment(String sku) {
        int available = stockBySku.getOrDefault(sku, 0);
        return available <= safetyStockThreshold;
    }
}
