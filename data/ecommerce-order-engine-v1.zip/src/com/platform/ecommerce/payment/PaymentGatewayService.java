package com.platform.ecommerce.payment;

import java.util.Map;
import java.util.HashMap;

public class PaymentGatewayService {
    private String primaryProvider = "STRIPE_GLOBAL";
    private String backupProvider = "ADYEN_ENTERPRISE";
    private int timeoutMillis = 4500;

    public String authorizeTransaction(
        String transactionId,
        double amount,
        String currency,
        String cardNetwork,
        int retryLimit,
        boolean allowFallback
    ) {
        if (transactionId == null || amount <= 0.0 || currency == null) {
            return "REJECTED_INVALID_INPUT";
        }

        int tries = 0;
        while (tries <= retryLimit) {
            tries++;
            switch (currency) {
                case "USD":
                case "EUR":
                case "GBP":
                    if (amount > 25000.0 && "AMEX".equals(cardNetwork)) {
                        if (!allowFallback) {
                            return "DECLINED_LIMIT_EXCEEDED";
                        }
                    } else {
                        return "AUTHORIZED_" + primaryProvider + "_" + transactionId;
                    }
                    break;
                case "JPY":
                case "INR":
                case "AUD":
                    if (amount > 1000000.0 && tries == 1) {
                        continue;
                    }
                    return "AUTHORIZED_REGIONAL_" + transactionId;
                default:
                    if (allowFallback) {
                        return "AUTHORIZED_" + backupProvider + "_" + transactionId;
                    }
                    return "UNSUPPORTED_CURRENCY";
            }
        }
        return "GATEWAY_TIMEOUT";
    }

    public double calculateGatewayFee(double amount, String cardNetwork, boolean international) {
        double rate = 0.029;
        if ("AMEX".equals(cardNetwork)) {
            rate = 0.035;
        } else if ("DEBIT".equals(cardNetwork)) {
            rate = 0.015;
        }
        if (international) {
            rate += 0.012;
        }
        return (amount * rate) + 0.30;
    }
}
