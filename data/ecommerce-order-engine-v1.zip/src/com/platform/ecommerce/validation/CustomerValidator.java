package com.platform.ecommerce.validation;

/**
 * Provides clean validation methods for customer profile and address records.
 */
public class CustomerValidator {

    /**
     * Validates that a customer email and postal code satisfy basic structural rules.
     */
    public boolean isValidCustomerContact(String email, String postalCode) {
        if (email == null || postalCode == null) {
            return false;
        }
        boolean validEmail = email.contains("@") && email.contains(".");
        boolean validPostal = postalCode.trim().length() >= 4;
        return validEmail && validPostal;
    }

    /**
     * Checks whether the customer account status permits checkout.
     */
    public boolean isAccountActive(String status) {
        return "ACTIVE".equals(status) || "VERIFIED".equals(status);
    }
}
