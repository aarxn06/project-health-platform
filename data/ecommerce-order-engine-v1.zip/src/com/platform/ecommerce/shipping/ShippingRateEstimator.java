package com.platform.ecommerce.shipping;

public class ShippingRateEstimator {

    public double estimateShippingCost(
        double totalWeightKg,
        String destinationZone,
        boolean isExpress,
        boolean isFragile,
        boolean hasInsurance,
        double declaredValue
    ) {
        if (totalWeightKg <= 0.0 || destinationZone == null) {
            return 0.0;
        }

        double baseCost = 8.50;
        if ("DOMESTIC_LOCAL".equals(destinationZone)) {
            baseCost = 6.00 + (totalWeightKg * 1.10);
        } else if ("DOMESTIC_REMOTE".equals(destinationZone)) {
            baseCost = 14.00 + (totalWeightKg * 2.25);
        } else if ("INTERNATIONAL_EU".equals(destinationZone)) {
            baseCost = 28.00 + (totalWeightKg * 4.50);
        } else if ("INTERNATIONAL_APAC".equals(destinationZone)) {
            baseCost = 34.00 + (totalWeightKg * 5.20);
        } else {
            baseCost = 42.00 + (totalWeightKg * 6.00);
        }

        if (isExpress) {
            baseCost *= 1.65;
        }
        if (isFragile) {
            baseCost += 12.50;
        }
        if (hasInsurance && declaredValue > 100.0) {
            baseCost += declaredValue * 0.015;
        }
        return baseCost;
    }
}
