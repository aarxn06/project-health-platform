package com.platform.ecommerce.audit;

import java.util.ArrayList;
import java.util.List;

/**
 * Records structured audit trail entries for order lifecycle transitions.
 */
public class OrderAuditLogger {
    private final List<String> entries = new ArrayList<>();

    /**
     * Appends a formatted event entry to the in-memory audit log.
     */
    public void recordEvent(String orderId, String eventType, String actor) {
        if (orderId == null || eventType == null) {
            return;
        }
        String safeActor = (actor != null && !actor.isEmpty()) ? actor : "SYSTEM";
        entries.add(orderId + "|" + eventType + "|" + safeActor);
    }

    /**
     * Returns the number of recorded audit events.
     */
    public int getEntryCount() {
        return entries.size();
    }
}
