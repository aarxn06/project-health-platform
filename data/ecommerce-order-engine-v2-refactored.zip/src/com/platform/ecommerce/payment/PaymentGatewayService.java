package com.platform.ecommerce.payment;

/**
 * Refactored payment gateway service with simplified currency routing and Javadoc documentation.
 */
public class PaymentGatewayService {
    private final String primaryProvider = "STRIPE_GLOBAL";
    private final String backupProvider = "ADYEN_ENTERPRISE";

    /**
     * Authorizes a payment transaction for supported currencies.
     */
    public String authorizeTransaction(String transactionId, double amount, String currency, boolean allowFallback) {
        if (transactionId == null || amount <= 0.0 || currency == null) {
            return "REJECTED_INVALID_INPUT";
        }
        if (isPrimaryCurrency(currency)) {
            return "AUTHORIZED_" + primaryProvider + "_" + transactionId;
        }
        if (allowFallback) {
            return "AUTHORIZED_" + backupProvider + "_" + transactionId;
        }
        return "UNSUPPORTED_CURRENCY";
    }

    private boolean isPrimaryCurrency(String currency) {
        return "USD".equals(currency) || "EUR".equals(currency) || "GBP".equals(currency) || "INR".equals(currency);
    }

    /**
     * Computes payment processing fee based on card type and cross-border flag.
     */
    public double calculateGatewayFee(double amount, String cardNetwork, boolean international) {
        double rate = "AMEX".equals(cardNetwork) ? 0.035 : 0.029;
        if (international) {
            rate += 0.012;
        }
        return (amount * rate) + 0.30;
    }
}
