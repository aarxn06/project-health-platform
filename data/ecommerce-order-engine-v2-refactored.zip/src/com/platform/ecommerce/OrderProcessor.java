package com.platform.ecommerce;

import java.util.List;
import java.util.Map;
import com.platform.ecommerce.pricing.DiscountCalculator;
import com.platform.ecommerce.shipping.ShippingRateEstimator;
import com.platform.ecommerce.validation.CustomerValidator;

/**
 * Refactored OrderProcessor that delegates pricing, shipping, and validation
 * to cohesive domain collaborators with reduced cyclomatic complexity.
 */
public class OrderProcessor {
    private final DiscountCalculator discountCalculator = new DiscountCalculator();
    private final ShippingRateEstimator shippingEstimator = new ShippingRateEstimator();
    private final CustomerValidator customerValidator = new CustomerValidator();
    private final double highValueThreshold = 5000.0;

    /**
     * Coordinates order validation, subtotal calculation, and final total determination.
     */
    public String processCheckoutWorkflow(
        String orderId,
        String customerId,
        List<String> skuList,
        Map<String, Integer> quantities,
        Map<String, Double> unitPrices,
        String couponCode,
        String shippingRegion
    ) {
        if (!isValidOrderHeader(orderId, customerId, skuList)) {
            return "INVALID_ORDER_PARAMETERS";
        }

        double grossTotal = calculateCartGrossTotal(skuList, quantities, unitPrices);
        if (grossTotal < 0.0) {
            return "INVALID_LINE_ITEMS";
        }

        double discount = discountCalculator.calculateDiscount(grossTotal, "GOLD", couponCode, skuList.size());
        double netTotal = Math.max(0.0, grossTotal - discount);
        double shippingFee = shippingEstimator.estimateShippingCost(2.5, shippingRegion, false, false, false, netTotal);
        double finalPayable = netTotal + shippingFee;

        if (finalPayable >= highValueThreshold) {
            return "REQUIRES_MANUAL_TREASURY_APPROVAL:" + orderId;
        }
        return "ORDER_CONFIRMED:" + orderId + ":" + finalPayable;
    }

    /**
     * Validates non-empty order identifier, customer identifier, and item list.
     */
    private boolean isValidOrderHeader(String orderId, String customerId, List<String> skuList) {
        if (orderId == null || orderId.isEmpty() || customerId == null || customerId.isEmpty()) {
            return false;
        }
        return skuList != null && !skuList.isEmpty();
    }

    /**
     * Sums line-item prices across valid SKUs or returns -1.0 when invalid quantities appear.
     */
    private double calculateCartGrossTotal(
        List<String> skuList,
        Map<String, Integer> quantities,
        Map<String, Double> unitPrices
    ) {
        if (quantities == null || unitPrices == null) {
            return -1.0;
        }
        double total = 0.0;
        for (String sku : skuList) {
            Integer qty = quantities.get(sku);
            Double price = unitPrices.get(sku);
            if (qty == null || qty <= 0 || price == null || price < 0.0) {
                return -1.0;
            }
            total += qty * price;
        }
        return total;
    }

    /**
     * Computes a bounded fraud risk indicator from chargeback history and account age.
     */
    public int evaluateOrderRiskScore(int priorChargebacks, boolean billingMatchesShipping, int accountAgeDays) {
        int score = priorChargebacks * 35;
        if (!billingMatchesShipping) {
            score += 20;
        }
        if (accountAgeDays < 7) {
            score += 15;
        }
        return Math.min(100, Math.max(0, score));
    }
}
